#!/usr/bin/env python3
"""
ESP32 Firmware Uploader Helper

This script sends a firmware binary to the master ESP32 for flashing
to the target ESP32.

Usage:
    python upload_firmware.py <serial_port> <firmware.bin>
    
Example:
    python upload_firmware.py COM3 blink.bin
    python upload_firmware.py /dev/ttyUSB0 firmware.bin
"""

import sys
import serial
import struct
import time
import os

def upload_firmware(port, firmware_path, baudrate=115200):
    # Check firmware file exists
    if not os.path.exists(firmware_path):
        print(f"Error: Firmware file '{firmware_path}' not found")
        return False
    
    # Read firmware
    with open(firmware_path, 'rb') as f:
        firmware = f.read()
    
    size = len(firmware)
    print(f"Firmware: {firmware_path}")
    print(f"Size: {size} bytes")
    
    # Open serial port
    try:
        ser = serial.Serial(port, baudrate, timeout=1)
        time.sleep(2)  # Wait for ESP32 reset
    except Exception as e:
        print(f"Error opening serial port: {e}")
        return False
    
    # Clear any pending data
    ser.reset_input_buffer()
    
    # Send 'U' command to start upload mode
    print("\nStarting upload mode...")
    ser.write(b'U')
    time.sleep(0.5)
    
    # Read any response
    while ser.in_waiting:
        print(ser.read(ser.in_waiting).decode('utf-8', errors='ignore'), end='')
    
    time.sleep(1)
    
    # Send size (4 bytes, little-endian)
    print(f"\nSending size: {size} bytes")
    ser.write(struct.pack('<I', size))
    
    time.sleep(0.1)
    
    # Send firmware data in chunks
    print("Sending firmware data...")
    chunk_size = 1024
    sent = 0
    
    while sent < size:
        chunk = firmware[sent:sent + chunk_size]
        ser.write(chunk)
        sent += len(chunk)
        
        progress = (sent / size) * 100
        print(f"\rProgress: {sent}/{size} bytes ({progress:.1f}%)", end='')
        
        # Small delay to prevent buffer overflow
        time.sleep(0.01)
    
    print("\n\nUpload complete! Waiting for flashing to finish...")
    
    # Read and display output
    start = time.time()
    while time.time() - start < 60:  # 60 second timeout
        if ser.in_waiting:
            data = ser.read(ser.in_waiting).decode('utf-8', errors='ignore')
            print(data, end='')
            
            if "=== Flashing complete! ===" in data:
                break
            if "failed" in data.lower():
                break
                
            start = time.time()  # Reset timeout on activity
        else:
            time.sleep(0.1)
    
    ser.close()
    return True

def main():
    if len(sys.argv) != 3:
        print("Usage: python upload_firmware.py <serial_port> <firmware.bin>")
        print("\nExamples:")
        print("  python upload_firmware.py COM3 blink.bin")
        print("  python upload_firmware.py /dev/ttyUSB0 firmware.bin")
        sys.exit(1)
    
    port = sys.argv[1]
    firmware = sys.argv[2]
    
    upload_firmware(port, firmware)

if __name__ == "__main__":
    main()
