# ESP32 UART Flasher

Program one ESP32 from another ESP32 using UART (serial) communication.

## Wiring Diagram

```
    MASTER ESP32                         TARGET ESP32
    ============                         ============
                                         
         GPIO17 (TX2) ──────────────────> GPIO3 (RX0/U0RXD)
         GPIO16 (RX2) <────────────────── GPIO1 (TX0/U0TXD)
         GPIO4        ──────────────────> EN (Reset/Enable)
         GPIO5        ──────────────────> GPIO0 (Boot)
         GND          ──────────────────> GND
         
    [USB to PC]                          [No USB needed]
```

### Physical Connection Table

| Master ESP32 Pin | Wire Color (Suggested) | Target ESP32 Pin |
|------------------|------------------------|------------------|
| GPIO17 (TX2)     | Yellow                 | GPIO3 (RX0)      |
| GPIO16 (RX2)     | Orange                 | GPIO1 (TX0)      |
| GPIO4            | Green                  | EN               |
| GPIO5            | Blue                   | GPIO0            |
| GND              | Black                  | GND              |

**Important Notes:**
- Do NOT connect VCC/3.3V between boards unless target has no power source
- If powering target from master, ensure total current draw is within limits
- Both boards must share a common ground (GND)

## Quick Start Guide

### Step 1: Upload Master Firmware

1. Open `master_flasher.ino` in Arduino IDE
2. Select your master ESP32 board
3. Upload to the master ESP32
4. Open Serial Monitor at 115200 baud

### Step 2: Wire the Boards

Connect the master and target ESP32s according to the wiring diagram above.

### Step 3: Prepare Target Firmware

Compile your firmware for the target ESP32:

**Using Arduino IDE:**
1. Open your sketch (or use `target_blink_test.ino` for testing)
2. Go to Sketch → Export Compiled Binary
3. Find the `.bin` file in your sketch folder

**Using PlatformIO:**
```bash
pio run
# Binary at: .pio/build/<env>/firmware.bin
```

**Using ESP-IDF:**
```bash
idf.py build
# Binary at: build/<project>.bin
```

### Step 4: Flash the Target

**Option A: Using SPIFFS (Recommended for repeated flashing)**

1. Upload `firmware.bin` to master's SPIFFS:
   - Use ESP32 Sketch Data Upload tool in Arduino IDE
   - Or use `esptool.py` to upload SPIFFS image
   
2. In Serial Monitor, send `F` to flash

**Option B: Using Python Helper Script**

```bash
# Install pyserial if needed
pip install pyserial

# Upload and flash
python upload_firmware.py COM3 firmware.bin
# or on Linux/Mac:
python upload_firmware.py /dev/ttyUSB0 firmware.bin
```

**Option C: Manual Serial Upload**

1. In Serial Monitor, send `U`
2. Send 4-byte size (little-endian)
3. Send firmware binary data

## Serial Commands

| Command | Description |
|---------|-------------|
| `F` | Flash firmware from SPIFFS (/firmware.bin) |
| `U` | Upload firmware via Serial, then flash |
| `S` | Sync with target bootloader |
| `R` | Reset target (normal boot) |
| `B` | Reset target into bootloader mode |
| `T` | Test connection to target |

## Troubleshooting

### "Sync failed"
- Check TX/RX wiring (they should be crossed: TX→RX, RX→TX)
- Verify GND connection
- Check EN and GPIO0 connections
- Try pressing reset on target while sending `S` command
- Ensure target ESP32 has power

### "Flash begin failed"
- Sync succeeded but flash failed
- May need to adjust timing in `enterBootloaderMode()`
- Try increasing delays

### "Failed to write block X"
- Communication interrupted
- Check for loose connections
- Reduce baud rate if using long wires

### Target doesn't boot after flashing
- Verify you're flashing to correct offset (0x10000 for app)
- Check firmware is compiled for ESP32 (not ESP8266)
- Try flashing a known-good binary like the blink test

## Technical Details

### ESP32 Boot Mode Selection

| GPIO0 | Mode |
|-------|------|
| HIGH (1) | Normal boot (run application) |
| LOW (0)  | Download boot (bootloader/flash mode) |

The master controls GPIO0 and EN to force the target into bootloader mode:
1. Pull GPIO0 LOW
2. Pulse EN (reset)
3. Release GPIO0
4. Target is now in bootloader mode, waiting for commands

### Bootloader Protocol

The ESP32 bootloader uses SLIP-encoded packets over UART:
- Default baud: 115200
- Frame: `0xC0 [header] [data] 0xC0`
- Escape: `0xDB 0xDC` = `0xC0`, `0xDB 0xDD` = `0xDB`

### Memory Map

| Address | Content |
|---------|---------|
| 0x1000  | Bootloader |
| 0x8000  | Partition table |
| 0x10000 | Application (default) |

## Customization

### Changing Pins

Modify these defines in `master_flasher.ino`:

```cpp
#define TARGET_TX_PIN   17    // Master TX → Target RX
#define TARGET_RX_PIN   16    // Master RX ← Target TX
#define TARGET_EN_PIN   4     // Controls target reset
#define TARGET_GPIO0_PIN 5    // Controls target boot mode
```

### Changing Flash Offset

To flash to a different partition, modify the offset in `flashFirmware()`:

```cpp
// Default: 0x10000 (app partition)
// Bootloader: 0x1000
// Partition table: 0x8000
if (!flashBegin(size, 0x10000)) {
```

### Increasing Baud Rate

For faster transfers, modify both master and bootloader baud:

```cpp
TargetSerial.begin(460800, SERIAL_8N1, TARGET_RX_PIN, TARGET_TX_PIN);
```

Note: Higher baud rates may be less reliable with longer wires.

## Files

- `master_flasher.ino` - Main flasher firmware for master ESP32
- `target_blink_test.ino` - Simple test firmware for target
- `upload_firmware.py` - Python helper to send firmware to master
- `README.md` - This file

## License

MIT License - Free to use and modify.
